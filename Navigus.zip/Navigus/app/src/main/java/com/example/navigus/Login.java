package com.example.navigus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    LoginDataBaseAdapter loginDataBaseAdapter;
    private static long back_pressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();

        final EditText editTextUserName=(EditText)findViewById(R.id.editText6);
        final EditText editTextPassword=(EditText)findViewById(R.id.editText7);
        Button btnSignIn=(Button)findViewById(R.id.button4);
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName=editTextUserName.getText().toString();
                String password=editTextPassword.getText().toString();
                String storedPassword=loginDataBaseAdapter.getSinlgeEntry(userName);
                if (password.equals(storedPassword))
                {

                    Intent in =new Intent(Login.this,Auth.class);

                    Bundle b= new Bundle();
                    b.putString("name", userName.toString());
                    in.putExtras(b);


                    startActivity(in);
                }
                else
                {
                    Toast.makeText(Login.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(getApplicationContext(),Unauth.class);
                    startActivity(intent);
                }



            }
        });

    }
}