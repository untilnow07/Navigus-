package com.example.navigus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

public class Auth extends AppCompatActivity {
    Date dbHandler;
    EditText editText;
    CalendarView calendarView;
    String selectedDate;
    SQLiteDatabase sqLiteDatabase;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        calendarView = findViewById(R.id.calendarView2);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                selectedDate = Integer.toString(dayOfMonth) +"/"+ Integer.toString(month) +"/"+ Integer.toString(year);
                //InsertDatabase(view);
            }
        });
         /* try{

            dbHandler = new Date(this, "CalendarDatabase", null,1);
            sqLiteDatabase = dbHandler.getWritableDatabase();
            sqLiteDatabase.execSQL("CREATE TABLE EventCalendar(Date TEXT, Event TEXT)");
        }
        catch (Exception e){
            e.printStackTrace();
        }*/

        Button button=(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),Time.class);
                Toast.makeText(getApplicationContext(),"Date:    "+ selectedDate,Toast.LENGTH_LONG).show();
                // intent.putExtra("any",selectedDate);
                startActivity(intent);


            }
        });

    }
     /*  public void InsertDatabase(View view){
        ContentValues contentValues = new ContentValues();
        contentValues.put("Date",selectedDate);

        sqLiteDatabase.insert("EventCalendar", null, contentValues);

    }*/

}