package com.example.navigus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Time extends AppCompatActivity {
    /* Intent intent=getIntent();
    Bundle extras = intent.getExtras();
    String tmp = extras.getString("myKey"); */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        final RadioGroup radioGroup=(RadioGroup)findViewById(R.id.groupradio);
        radioGroup.clearCheck();

        Button button=(Button)findViewById(R.id.submit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioID=radioGroup.getCheckedRadioButtonId();
                Intent intent= new Intent(getApplicationContext(),last.class);
                RadioButton radioButton=findViewById(radioID);
                Toast.makeText(getApplicationContext(), "Slot:  " + radioButton.getText(),Toast.LENGTH_LONG).show();

                startActivity(intent);
            }
        });

    }
}